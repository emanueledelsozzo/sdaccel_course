#include "kernel.hpp"

void kernel(myStreamAP &a, myStreamAP &b, myStreamAP &c, myStream &d){
#pragma HLS INTERFACE axis register both port=a
#pragma HLS INTERFACE axis register both port=b
#pragma HLS INTERFACE axis register both port=c
#pragma HLS INTERFACE axis register both port=d

#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma DATAFLOW

	streamType d_tmp = d.read();
	float d_val = d_tmp.data;

	loop:for(int i = 0; i < N_AP; i++){
#pragma HLS PIPELINE
		ap_uint<512> a_val;
		streamTypeAP b_tmp = b.read();
		ap_uint<512> b_val = b_tmp.data;
		streamTypeAP c_tmp = c.read();
		ap_uint<512> c_val = c_tmp.data;
		for(int j = 0; j < 16; j++){
			int upper = (j+1)*32 - 1;
			int lower = j*32;
			unsigned int b_tmp_uint = b_val.range(upper, lower);
			unsigned int c_tmp_uint = c_val.range(upper, lower);
			float b_valF = *((float *)&b_tmp_uint);
			float c_valF = *((float *)&c_tmp_uint);
			float a_valF = b_valF + c_valF*d_val;
			a_val.range(upper, lower) = *((unsigned int *)&a_valF);
		}
		streamTypeAP a_tmp;
		a_tmp.data = a_val;
		a_tmp.last = i == N_AP - 1;
		a.write(a_tmp);
	}

}
