#ifndef KERNEL_HPP
#define KERNEL_HPP

#define N 16000
#define N_AP (N/16)
#include "hls_stream.h"
#include "ap_int.h"

template<class DT, int D,int U,int TI,int TD>
  struct my_ap_axis{
    DT       data;
    ap_uint<(D+7)/8> keep;
    ap_uint<(D+7)/8> strb;
    ap_uint<U>       user;
    ap_uint<1>       last;
    ap_uint<TI>      id;
    ap_uint<TD>      dest;
  };

typedef my_ap_axis<float, 32, 1, 1, 1> streamType;
typedef hls::stream<streamType> myStream;
typedef ap_uint<512> ap_512;
typedef my_ap_axis<ap_512, 512, 1, 1, 1> streamTypeAP;
typedef hls::stream<streamTypeAP> myStreamAP;

#endif
