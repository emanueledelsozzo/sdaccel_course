#include <stdio.h>
#include <stdlib.h>
#include "kernel.hpp"
#define X 20

void kernel(myStreamAP &a, myStreamAP &b, myStreamAP &c, myStream &d);

int main(){

	float aCPU[N], aFPGA[N], b[N], c[N], d;
	myStreamAP aStream, bStream, cStream;
	myStream dStream;
	streamType dType;
	streamTypeAP aType, bType, cType;

	srand(0);
	d = (float) rand() / ((float) (RAND_MAX/X));
	for(int i = 0; i < N; i++){
		b[i] = (float) rand() / ((float) (RAND_MAX/X));
		c[i] = (float) rand() / ((float) (RAND_MAX/X));
	}
	for(int i = 0; i < N; i++){
		aCPU[i] = b[i] + c[i]*d;
	}
	for(int i = 0; i < N_AP; i++){
		ap_uint<512> bAP;
		ap_uint<512> cAP;
		for(int j = 0; j < 16; j++){
			int upper = (j+1)*32 - 1;
			int lower = j*32;
			float bVal = b[i*16 + j];
			float cVal = c[i*16 + j];
			bAP.range(upper, lower) = *((unsigned int *)&bVal);
			cAP.range(upper, lower) = *((unsigned int *)&cVal);
		}
		bType.data = bAP;
		bType.last = i == N_AP - 1;
		bStream.write(bType);
		cType.data = cAP;
		cType.last = i == N_AP - 1;
		cStream.write(cType);
	}
	dType.data = d;
	dType.last = 1;
	dStream.write(dType);

	kernel(aStream, bStream, cStream, dStream);

	for(int i = 0; i < N_AP; i++){
		aType = aStream.read();
		ap_uint<512> aAP = aType.data;
		for(int j = 0; j < 16; j++){
			int upper = (j+1)*32 - 1;
			int lower = j*32;
			unsigned int a_tmp = aAP.range(upper, lower);
			aFPGA[i*16 + j] = *((float *)&a_tmp);
			if(aCPU[i*16 + j] != aFPGA[i*16 + j]){
				printf("Error at index %d: %f != %f\n", i*16 + j, aCPU[i*16 + j], aFPGA[i*16 + j]);
				return 1;
			}
		}
	}

	return 0;

}
