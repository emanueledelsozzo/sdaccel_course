#include "string.h"
#include "ap_int.h"
#define N 16000
#define N_AP (N/16)

void kernel(ap_uint<512> *a, ap_uint<512> *b, ap_uint<512> *c, float d){
#pragma HLS INTERFACE m_axi depth=1000 port=a bundle=gmem0
#pragma HLS INTERFACE m_axi depth=1000 port=b bundle=gmem1
#pragma HLS INTERFACE m_axi depth=1000 port=c bundle=gmem2

#pragma HLS INTERFACE s_axilite port=a
#pragma HLS INTERFACE s_axilite port=b
#pragma HLS INTERFACE s_axilite port=c
#pragma HLS INTERFACE s_axilite port=d
#pragma HLS INTERFACE s_axilite port=return

	ap_uint<512> a_local[N_AP], b_local[N_AP], c_local[N_AP];
	float d_local;

	memcpy(b_local, b, sizeof(ap_uint<512>)*N_AP);
	memcpy(c_local, c, sizeof(ap_uint<512>)*N_AP);
	d_local = d;

	loop1:for(int i = 0; i < N_AP; i++){
#pragma HLS PIPELINE
		loop2:for(int j = 0; j < 16; j++){
			int upper = (j+1)*32 - 1;
			int lower = j*32;
			unsigned int b_tmp = b_local[i].range(upper, lower);
			unsigned int c_tmp = c_local[i].range(upper, lower);
			float b_val = *((float *)&b_tmp);
			float c_val = *((float *)&c_tmp);
			float a_val = b_val + c_val*d_local;
			a_local[i].range(upper, lower) = *((unsigned int *)&a_val);
		}
	}

	memcpy(a, a_local, sizeof(ap_uint<512>)*N_AP);

}
